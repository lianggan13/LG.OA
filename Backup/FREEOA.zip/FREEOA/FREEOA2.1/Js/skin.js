


function bbsxptop(){
document.write("")
}

function bbsxpbottom(){
document.write("")
}

function bottomtable(){
document.write("<table cellpadding=0 cellspacing=0 width=360 align=center><tr><td><img src=images/skins/1/B_left.gif></td><td width=100% background=images/skins/1/B_bg.gif></td><td><img src=images/skins/1/B_right.gif></td></tr></table>")
}

function toptable(){
document.write("<table cellpadding=0 cellspacing=0 width=360 align=center><tr><td><img src=images/skins/1/T_left.gif></td><td width=100% background=images/skins/1/T_bg.gif></td><td><img src=images/skins/1/T_right.gif></td></tr></table>")
}
